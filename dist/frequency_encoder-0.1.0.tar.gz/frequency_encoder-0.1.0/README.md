# Frequency Encoder

A frequency encoder for pandas DataFrames compatible with scikit-learn pipelines.

## Installation

```bash
pip install git+https://github.com/crisbebop/frequency_encoder.git
