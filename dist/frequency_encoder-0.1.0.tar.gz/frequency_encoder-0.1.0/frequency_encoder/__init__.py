from .encoder import FrequencyEncoder
